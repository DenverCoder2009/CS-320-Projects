package contact;

import java.lang.String;

public class Contact 
{
    
	public class java {

	}

	private String contactID;
	private String firstName;
	private String lastName;
	private String phone;
	private String adress;
	
	
	public Contact()
	{
		this.contactID =  " ";
		this.firstName =  " ";
		this.lastName =  " ";
		this.phone = " ";
		this.adress = " ";
	}
	public Contact(String contactID, String firstName, String lastName, String phone, String adress)
	{
		this.contactID =  contactID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phone = phone;
		this.adress = adress;
	}
	
	public String getContactID() {
		return contactID;
	}

	public void setContactID(String contactID) {
		this.contactID = contactID;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getAdress() {
		return adress;
	}

	public void setAdress(String adress) {
		this.adress = adress;
	}

}
