package contact;
import java.util.*;
import java.io.*;
//import java.lang.System;
import java.util.NoSuchElementException;
//import java.io.PrintStream;


public class ContactService
{

	private ArrayList<Contact> contactList; 
	
	public ContactService()
	{
		contactList = new ArrayList<Contact>(0);
	}
	public ContactService(String contactID, String firstName, String lastName, String phone, String adress)
	{
	        contactList = new ArrayList<Contact>(0);
	        this.addContact(contactID, firstName, lastName, phone, adress);
    }
	
	public ArrayList<Contact> getContactList()
	{
		ArrayList<Contact> tempContact = new ArrayList<Contact>();
		tempContact = (ArrayList<Contact>)contactList.clone();//we do this so we dont return the pointer and leave data acessable
		return tempContact;
	}
	public void findDuplicateContact(String ContactID)
	{

		for (int i = 0; i < contactList.size(); ++i)
		{
			if (contactList.get(i).getContactID().equals(ContactID))
			{
				throw new IllegalArgumentException("Duplicate task exists");
			}
		}
		
	}
	public int findContact(String contactID)
	{
		int contactIndex = -1;
		for (int i = 0; i < contactList.size(); ++i)
		{
			if (contactList.get(i).getContactID().equals(contactID))
			{
				contactIndex = i;
			}
		}
		if (contactIndex == -1)
		{
			throw new IllegalArgumentException("No such contact");
		}
		return contactIndex;
		
	}
	public void idValidation(String contactID) 
	{
		if (contactID == null || contactID.length() > 10)
		{
			throw new IllegalArgumentException("invalid contact ID");
			
		}
	}
	public void firstNameValidation(String firstName)
	{
		if (firstName == null || firstName.length() > 10)
		{
			throw new IllegalArgumentException("invalid first name");
			
		}
	}
	public void lastNameValidation( String lastName)
	{
		if (lastName == null || lastName.length() > 10)
		{
			System.out.println("we made it to lastName null");
			throw new IllegalArgumentException("invalid last name");
			
		}
	}
	public void phoneValidation(String phone)
	{
		if (phone == null || phone.length() > 10 || phone.length() < 10)
		{
			System.out.println("we made it to phone null");
			throw new IllegalArgumentException("invalid phone number");
			
		}
	}
	public void adressValidation( String adress)
	{
		if (adress == null || adress.length() > 30)
		{
			throw new IllegalArgumentException("invalid adress");
			
		}
	}
	public void notEmptyValidation()
	{
		if (contactList.isEmpty())
		{
			throw new NoSuchElementException("Contact list is empty already.");
			
		}
	}
	public void addContact(String contactID, String firstName, String lastName, String phone, String adress)
	{
		 	findDuplicateContact(contactID);
		    idValidation(contactID);
		    firstNameValidation(firstName);
		    lastNameValidation(lastName);
		    phoneValidation(phone);
		    adressValidation(adress);
		    System.out.println("we made it past the point in contact");
			Contact newContact = new Contact(contactID, firstName, lastName, phone, adress);
		    contactList.add(newContact);
		
	}
	public void deleteContact(String contactID)
	{
		
		int contactIndex;
		idValidation(contactID);
		notEmptyValidation();	
		contactIndex = findContact(contactID);
		contactList.remove(contactIndex);
	}
	public void updateFirstName(String contactID, String newFirstName)
	{
		idValidation(contactID);
		firstNameValidation(newFirstName);
		notEmptyValidation();
		int contactIndex;
		contactIndex = findContact(contactID);
		contactList.get(contactIndex).setFirstName(newFirstName);
	}
	public void updateLastName(String contactID, String newLastName)
	{
		idValidation(contactID);
		lastNameValidation(newLastName);
		notEmptyValidation();
		int contactIndex;
		contactIndex = findContact(contactID);
		contactList.get(contactIndex).setLastName(newLastName);
	}
	public void updatePhone(String contactID, String newPhone)
	{
		idValidation(contactID);
		phoneValidation(newPhone);
		notEmptyValidation();
		int contactIndex;
		contactIndex = findContact(contactID);
		contactList.get(contactIndex).setPhone(newPhone);
	}
	public void updateAdress(String contactID, String newAdress)
	{
		idValidation(contactID);
		adressValidation(newAdress);
		notEmptyValidation();
		int contactIndex;
	    contactIndex = findContact(contactID);
		contactList.get(contactIndex).setAdress(newAdress);
	}
	
}
