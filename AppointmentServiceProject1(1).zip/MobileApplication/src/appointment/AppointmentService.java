package appointment;

import java.util.ArrayList;
import java.util.NoSuchElementException;
import java.util.Date;


public class AppointmentService 
{
private ArrayList<Appointment> appointmentList;
	
	public AppointmentService()
	{
		appointmentList = new ArrayList<Appointment>(0);
	}
	public AppointmentService(String appointmentId, Date appointmentDate, String appointmentDescription)
	{
	        appointmentList = new ArrayList<Appointment>(0);
	        this.addAppointment(appointmentId, appointmentDate, appointmentDescription);
    }
	
	public ArrayList<Appointment> getAppointmentList()
	{
		ArrayList<Appointment> tempAppointment = new ArrayList<Appointment>();
		tempAppointment = (ArrayList<Appointment>)appointmentList.clone();//we do this so we dont return the pointer and leave data acessable
		return tempAppointment;
	}
	public int findAppointment(String appointmentId)
	{
		int appointmentIndex = -1;
		for (int i = 0; i < appointmentList.size(); ++i)
		{
			if (appointmentList.get(i).getAppointmentId().equals(appointmentId))
			{
				appointmentIndex = i;
			}
		}
		if (appointmentIndex == -1)
		{
			throw new IllegalArgumentException("No such Appointment");
		}
		return appointmentIndex;
		
	}
	public void findDuplicateAppointment(String appointmentId)
	{

		for (int i = 0; i < appointmentList.size(); ++i)
		{
			if (appointmentList.get(i).getAppointmentId().equals(appointmentId))
			{
				throw new IllegalArgumentException("Duplicate Appointment exists");
			}
		}
		
	}
	public void idValidation(String appointmentId) 
	{
		if (appointmentId == null || appointmentId.length() > 10)
		{
			throw new IllegalArgumentException("invalid Appointment ID");
			
		}
	}
	public void appointmentDateValidation(Date appointmentDate)
	{
		if (appointmentDate == null || appointmentDate.before(new Date()))
		{
			throw new IllegalArgumentException("invalid Appointment Date");
		}	
		
	}
	
	public void appointmentDescriptionValidation(String appointmentDescription)
	{
		if (appointmentDescription == null || appointmentDescription.length() > 50)
		{
			throw new IllegalArgumentException("invalid description");
			
		}
	}
	public void notEmptyValidation()
	{
		if (appointmentList.isEmpty())
		{
			throw new NoSuchElementException("Appointment list is empty already.");
			
		}
	}
	public void addAppointment(String appointmentId, Date appointmentDate, String appointmentDescription)
	{
		idValidation(appointmentId);
		findDuplicateAppointment(appointmentId);
		appointmentDateValidation(appointmentDate);
		appointmentDescriptionValidation(appointmentDescription);
		Appointment newAppointment = new Appointment(appointmentId, appointmentDate, appointmentDescription);
		appointmentList.add(newAppointment);
		
	}
	public void deleteAppointment(String appointmentId)
	{
		int appointmentIndex;
		idValidation(appointmentId);
		notEmptyValidation();	
		appointmentIndex = findAppointment(appointmentId);
		appointmentList.remove(appointmentIndex);
	}
}
