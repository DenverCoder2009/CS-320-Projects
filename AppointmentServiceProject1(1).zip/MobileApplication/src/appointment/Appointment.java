package appointment;
import java.util.Date;
public class Appointment 
{
	private String appointmentId;
	private Date appointmentDate;
	private String appointmentDescription;
	
	public Appointment() 
	{
		this.appointmentId = " ";
		this.appointmentDate = new Date();
		this.appointmentDescription = " ";
	}
	public Appointment(String newAppointmentId, Date newDate, String newAppointmentDescription)
	{
		this.appointmentId = newAppointmentId;
		this.appointmentDate = newDate;
		this.appointmentDescription = newAppointmentDescription;
	}
	public String getAppointmentId() {
		return appointmentId;
	}
	public void setAppointmentId(String newAppointmentId) {
		this.appointmentId = newAppointmentId;
	}
	public Date getAppointmentDate() {
		return this.appointmentDate;
	}
	public void setAppointmentDate(Date newDate) {
		this.appointmentDate = newDate;
	}
	public String getAppointmentDescription() {
		return this.appointmentDescription;
	}
	public void setAppointmentDescription(String newAppointmentDescription) {
		this.appointmentDescription = newAppointmentDescription;
	}
	
}


