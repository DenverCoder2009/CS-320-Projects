package task;
import java.lang.String;
public class Task 
{
	private String taskID;
	private String taskName;
	private String taskDescription;
	
	public Task() 
	{
		this.taskID = " ";
		this.taskName = " ";
		this.taskDescription = " ";
	}
	public Task(String newTaskID, String newTaskName, String newTaskDescription)
	{
		this.taskID = newTaskID;
		this.taskName = newTaskName;
		this.taskDescription = newTaskDescription;
	}
	public String getTaskID() {
		return taskID;
	}
	public void setTaskID(String taskID) {
		this.taskID = taskID;
	}
	public String getTaskName() {
		return taskName;
	}
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	public String getTaskDescription() {
		return taskDescription;
	}
	public void setTaskDescription(String taskDescription) {
		this.taskDescription = taskDescription;
	}
	
}
