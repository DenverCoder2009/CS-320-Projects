package task;

import java.util.ArrayList;
import java.util.NoSuchElementException;
public class TaskService 
{
	private ArrayList<Task> taskList;
	 
	public TaskService()
	{
		taskList = new ArrayList<Task>(0);
	}
	public TaskService(String taskID, String taskName, String description)
	{
	        taskList = new ArrayList<Task>(0);
	        this.addTask(taskID, taskName, description);
    }
	
	public ArrayList<Task> getTaskList()
	{
		ArrayList<Task> tempTask = new ArrayList<Task>();
		tempTask = (ArrayList<Task>)taskList.clone();//we do this so we dont return the pointer and leave data acessable
		return tempTask;
	}
	public int findTask(String taskID)
	{
		int taskIndex = -1;
		for (int i = 0; i < taskList.size(); ++i)
		{
			if (taskList.get(i).getTaskID().equals(taskID))
			{
				taskIndex = i;
			}
		}
		if (taskIndex == -1)
		{
			throw new IllegalArgumentException("No such task");
		}
		return taskIndex;
		
	}
	public void findDuplicateTask(String taskID)
	{

		for (int i = 0; i < taskList.size(); ++i)
		{
			if (taskList.get(i).getTaskID().equals(taskID))
			{
				throw new IllegalArgumentException("Duplicate task exists");
			}
		}
		
	}
	public void idValidation(String taskID) 
	{
		if (taskID == null || taskID.length() > 10)
		{
			throw new IllegalArgumentException("invalid task ID");
			
		}
	}
	public void taskNameValidation(String taskName)
	{
		if (taskName == null || taskName.length() > 20)
		{
			throw new IllegalArgumentException("invalid task name");
			
		}
	}
	
	public void descriptionValidation( String adress)
	{
		if (adress == null || adress.length() > 50)
		{
			throw new IllegalArgumentException("invalid description");
			
		}
	}
	public void notEmptyValidation()
	{
		if (taskList.isEmpty())
		{
			throw new NoSuchElementException("Contact list is empty already.");
			
		}
	}
	public void addTask(String taskID, String taskName, String description)
	{
		 System.out.println("Before");
		    idValidation(taskID);
		    findDuplicateTask(taskID);
		    taskNameValidation(taskName);
		    
		    descriptionValidation(description);
		    System.out.println("we made it past the point in contact");
			Task newTask = new Task(taskID, taskName, description);
		    taskList.add(newTask);
		
	}
	public void deleteTask(String taskID)
	{
		
		int taskIndex;
		idValidation(taskID);
		notEmptyValidation();	
		taskIndex = findTask(taskID);
		taskList.remove(taskIndex);
	}
	public void updateTaskName(String taskID, String newTaskName)
	{
		idValidation(taskID);
		taskNameValidation(newTaskName);
		notEmptyValidation();
		int taskIndex;
		taskIndex = findTask(taskID);
		taskList.get(taskIndex).setTaskName(newTaskName);
	}
	
	
	public void updateDescription(String taskID, String newDescription)
	{
		idValidation(taskID);
		descriptionValidation(newDescription);
		notEmptyValidation();
		int taskIndex;
	    taskIndex = findTask(taskID);
		taskList.get(taskIndex).setTaskDescription(newDescription);
	}
	
}

