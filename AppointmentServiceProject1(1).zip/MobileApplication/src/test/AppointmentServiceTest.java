package test;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.lang.System;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

//import task.Task;
//import task.TaskService;
import appointment.Appointment;
import appointment.AppointmentService;
import java.util.Date;

class AppointmentServiceTest {

	//@Disabled
		@Test
		
		void testAppointmentServiceIDTooLong() 
		{
			Assertions.assertThrows(IllegalArgumentException.class, () ->
			{
				new AppointmentService("12345678901", new Date(), "finish test cases");
		
			});
		}
		@Test
		void testAppointmentServiceDatePast() 
		{
			Assertions.assertThrows(IllegalArgumentException.class, () ->
			{
				new AppointmentService("1234567890", new Date(20), "finish test cases");
		
			});
			
			
		}
		@Test
		void testAppointmentServiceDescriptionTooLong() 
		{
			Assertions.assertThrows(IllegalArgumentException.class, () ->
			{
				new AppointmentService("1234567890", new Date(), "make sure that one of the test cases has a description over 50");
		
			});
			
			
		}
		//@Disabled
		@Test
		void testAppointmentServiceIDNULL() 
		{
			Assertions.assertThrows(IllegalArgumentException.class, () ->
			{
				new AppointmentService(null, new Date(), "finish test cases");
		
			});
			
			
		}
		//@Disabled
		@Test
		void testAppointmentServiceDateNULL() 
		{
			Assertions.assertThrows(IllegalArgumentException.class, () ->
			{
				new AppointmentService("1234567890", null, "finish test cases");
		
			});
			
			
		}
		//@Disabled
		@Test
		void testAppointmentServiceDescriptionNull() 
		{
			Assertions.assertThrows(IllegalArgumentException.class, () ->
			{
				new AppointmentService("1234567890", new Date(),  null);
		
			});
			
			
		}
		//@Disabled
	    @Test
		void testAppointmentServiceAddAppointment() 
		{ 
			ArrayList<Appointment> tempArrayList = new ArrayList<Appointment>(0);
	    	     
			AppointmentService testList = new AppointmentService(); 
			testList.addAppointment("1234567890", new Date(), "finish test cases");
			tempArrayList = testList.getAppointmentList();//this is necessary because i made the list private
			Iterator<Appointment> listIterator = tempArrayList.iterator();
			while (listIterator.hasNext())
			{
				Appointment element = listIterator.next();
				assertTrue(element.getAppointmentId().equals("1234567890"));
				assertTrue(element.getAppointmentDate().equals(new Date()));
				assertTrue(element.getAppointmentDescription().equals( "finish test cases"));
				
			}
			
		}
	   // @Disabled
	    @Test
	   	void testAppointmentServiceAddandDelete() 
	   	{ //"8675309505", "complete project", "openGL 3d modeling"
	   		//ArrayList<Appointment> tempArrayList = new ArrayList<Appointment>(0);
	   		AppointmentService testList = new AppointmentService(); 
	   		testList.addAppointment("1234567890", new Date(), "finish test cases");
	   		//tempArrayList = testList.getAppointmentList();
	   		testList.deleteAppointment("1234567890");
	   		
	   		Assertions.assertThrows(NoSuchElementException.class, () ->
			{
				testList.notEmptyValidation();
		
			});
	   		
	   	}
	    @Test
	   	void testAppointmentServiceMultipleAppointments() 
	   	{ //"1234567890", "complete project", "openGL 3d modeling"
	    	//"8675309505", "check work", make sure all test cases accounted for"
	    	Date todaysDate = new Date();
	    	Date futureDate = new Date(System.currentTimeMillis()+9000);
	    	
	   		ArrayList<Appointment> tempArrayList = new ArrayList<Appointment>(0);
	   		AppointmentService testList = new AppointmentService(); 
	   		testList.addAppointment("1234567890", todaysDate, "finish test cases");
	   		testList.addAppointment("8675309505", futureDate, "make sure all test cases accounted for");
	   		tempArrayList = testList.getAppointmentList();
	   		
	   		Iterator<Appointment> listIterator = tempArrayList.iterator();
	   		int count = 0;
	   		while (listIterator.hasNext())
	   		{
	   			Appointment element = listIterator.next();
	   			
	   			if (count == 0)
	   			{
	   			assertTrue(element.getAppointmentId().equals("1234567890"));
				assertTrue(element.getAppointmentDate().compareTo(todaysDate) == 0);
				assertTrue(element.getAppointmentDescription().equals("finish test cases"));
	   			}
	   			
	   			if (count == 1)
	   			{
	   				assertTrue(element.getAppointmentId().equals("8675309505"));
	   				assertTrue(element.getAppointmentDate().compareTo(futureDate) == 0);
	   				assertTrue(element.getAppointmentDescription().equals("make sure all test cases accounted for"));
	   			}
	   			count++;
	   		}
	   	}
	    @Test
	   	void testAppointmentServiceDuplicateAppointment() 
	   	{ //"1234567890", "complete project", "openGL 3d modeling"
	    	//"8675309505", "check work", make sure all test cases accounted for"
	    	Date todaysDate = new Date();
	   		AppointmentService testList = new AppointmentService(); 
	   		testList.addAppointment("1234567890", todaysDate, "finish test cases");
			
			  Assertions.assertThrows(IllegalArgumentException.class, () -> {
			  testList.addAppointment("1234567890", todaysDate, "make sure all test cases accounted for");
			  
			  });
			 
	   	}

}
