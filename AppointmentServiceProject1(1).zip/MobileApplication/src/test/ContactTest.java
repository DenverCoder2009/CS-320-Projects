package test;
import contact.Contact;

import static org.junit.jupiter.api.Assertions.*;
/*TEST TEMPLATES
  Contact("12345678901", "Johnathanny", "Smithington", "10987654321", "25000 welcome to longer than 30"); //all invalid
  Contact("1234567890", "John", "Smith", "0987654321", "my short adress"); // all valid
 */
import org.junit.jupiter.api.Test;

class ContactTest {

	@Test
	void defaultConstructorTest() 
	{
		Contact myContact = new Contact();
		assertTrue(myContact.getFirstName() != null);
		assertTrue(myContact.getLastName() != null);
		assertTrue(myContact.getPhone() != null);
		assertTrue(myContact.getAdress() != null);
		assertTrue(myContact.getContactID() != null);
	}
	@Test
	void constuctorWithArgs()
	{
		Contact myContact = new Contact("1234567890", "John", "Smith", "0987654321", "my short adress");
		assertTrue(myContact.getContactID().equals("1234567890"));
		assertTrue(myContact.getFirstName().equals("John"));
		assertTrue(myContact.getLastName().equals("Smith"));
		assertTrue(myContact.getPhone().equals("0987654321"));
		assertTrue(myContact.getAdress().equals("my short adress"));
		
	}

}
