package test;

import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;
import org.junit.jupiter.api.Test;

import appointment.Appointment;

class AppointmentTest {

	@Test
	void defaultConstructorTest() 
	{
		Appointment myAppointment = new Appointment();
		assertTrue(myAppointment.getAppointmentId() != null);
		assertTrue(myAppointment.getAppointmentDate() != null);
		assertTrue(myAppointment.getAppointmentDescription() != null);
	}
	@Test
	void constuctorWithArgs()
	{
		Appointment myAppointment = new Appointment("1234567890", new Date(), "Finish the test cases");
		assertTrue(myAppointment.getAppointmentId().equals("1234567890"));
		assertTrue(myAppointment.getAppointmentDate().equals(new Date()));
		assertTrue(myAppointment.getAppointmentDescription().equals("Finish the test cases"));
		
	}


}
