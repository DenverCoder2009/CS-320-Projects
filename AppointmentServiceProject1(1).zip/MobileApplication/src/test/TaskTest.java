package test;

/*TaskService("12345678901", "do homework longer than 20", "make sure that one of the test cases has a description over 50"); //all invalid
TaskService("1234567890", "do homework", "finish test cases"); // all valid
TaskService("8675309505", "complete project", "openGL 3d modeling"); //all valid
*/
import task.Task;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class TaskTest {

	@Test
	void defaultConstructorTest() 
	{
		Task myContact = new Task();
		assertTrue(myContact.getTaskName() != null);
		assertTrue(myContact.getTaskDescription() != null);
		assertTrue(myContact.getTaskID() != null);
	}
	@Test
	void constuctorWithArgs()
	{
		Task myContact = new Task("1234567890", "do homework", "Finish the test cases");
		assertTrue(myContact.getTaskID().equals("1234567890"));
		assertTrue(myContact.getTaskName().equals("do homework"));
		assertTrue(myContact.getTaskDescription().equals("Finish the test cases"));
		
	}

}
