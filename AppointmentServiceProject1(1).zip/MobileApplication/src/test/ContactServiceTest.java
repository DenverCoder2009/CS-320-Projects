package test;
import static org.junit.Assert.assertTrue;

import java.io.*;
import contact.ContactService;
import task.Task;
import task.TaskService;
import contact.Contact;
import java.util.*;

import org.junit.jupiter.api.Assertions;
//import static org.junit.jupiter.api.Assertions.*;
import org.junit.Ignore;
import org.junit.jupiter.api.Disabled;

//import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.TestInstance;
//import org.junit.jupiter.api.TestInstance.Lifecycle;
/*TEST TEMPLATES
ContactService("12345678901", "Johnathanny", "Smithington", "10987654321", "25000 welcome to longer than 30"); //all invalid
ContactService("1234567890", "John", "Smith", "0987654321", "my short adress"); // all valid
ContactService("8675309505", "Jacob", "Jameson", "8771500123", "my different adress"); //all valid
*/
//@TestInstance(Lifecycle.PER_CLASS)
class ContactServiceTest {
	//@Disabled
	@Test
	
	void testContactServiceIDTooLong() 
	{
		Assertions.assertThrows(IllegalArgumentException.class, () ->
		{
			new ContactService("12345678901", "John", "Smith", "0987654321", "my short adress");
	
		});
		
		
	}
	//@Disabled
	@Test
	void testContactServiceFirstNameTooLong() 
	{
		Assertions.assertThrows(IllegalArgumentException.class, () ->
		{
			new ContactService("1234567890", "Johnathanny", "Smith", "0987654321", "my short adress");
	
		});
		
		
	}
	//@Disabled
	@Test
	void testContactServiceLastNameTooLong() 
	{
		Assertions.assertThrows(IllegalArgumentException.class, () ->
		{
			new ContactService("1234567890", "John", "Smithington", "0987654321", "my short adress");
	
		});
		
		
	}
	//@Disabled
	@Test
	void testContactServicePhoneTooLong() 
	{
		
		Assertions.assertThrows(IllegalArgumentException.class, () ->
		{
			new ContactService("1234567890", "John", "Smith", "10987654321", "my short adress");
	
		});
		
		
	}
	//@Disabled
	@Test
	void testContactServicePhoneTooShort() 
	{
		Assertions.assertThrows(IllegalArgumentException.class, () ->
		{
			new ContactService("1234567890", "John", "Smith", "987654321", "my short adress");
	
		});
		
		
	}
	//@Disabled
	@Test
	void testContactServiceAdressTooLong() 
	{
		Assertions.assertThrows(IllegalArgumentException.class, () ->
		{
			new ContactService("1234567890", "John", "Smith", "0987654321", "25000 welcome to longer than 30");
	
		});
		
		
	}
	//@Disabled
	@Test
	void testContactServiceIDNULL() 
	{
		Assertions.assertThrows(IllegalArgumentException.class, () ->
		{
			new ContactService(null, "John", "Smith", "0987654321", "my short adress");
	
		});
		
		
	}
	//@Disabled
	@Test
	void testContactServiceFirstNameNULL() 
	{
		Assertions.assertThrows(IllegalArgumentException.class, () ->
		{
			new ContactService("12345678901", null, "Smith", "0987654321", "my short adress");
	
		});
		
		
	}
	//@Disabled
	@Test
	void testContactServiceLastNameNull() 
	{
		Assertions.assertThrows(IllegalArgumentException.class, () ->
		{
			new ContactService("12345678901", "John", null, "0987654321", "my short adress");
	
		});
		
		
	}
	//@Disabled
	@Test
	void testContactServicePhoneNull() 
	{
		Assertions.assertThrows(IllegalArgumentException.class, () ->
		{
			new ContactService("12345678901", "John", "Smith", null, "my short adress");
	
		});
		
		
	}
	//@Disabled
	@Test
	void testContactServiceAdressNull() 
	{
		Assertions.assertThrows(IllegalArgumentException.class, () ->
		{
			new ContactService("12345678901", "John", "Smith", "0987654321", null);
	
		});
		
		
	}
	//@Disabled
    @Test
	void testContactServiceAddContact() 
	{ 
		ArrayList<Contact> tempArrayList = new ArrayList<Contact>(0);
    	     
		ContactService testList = new ContactService(); 
		testList.addContact("1234567890", "John", "Smith", "0987654321", "my short adress");
		tempArrayList = testList.getContactList();//this is necessary because i made the list private
		Iterator<Contact> listIterator = tempArrayList.iterator();
		while (listIterator.hasNext())
		{
			Contact element = listIterator.next();
			assertTrue(element.getContactID().equals("1234567890"));
			assertTrue(element.getFirstName().equals("John"));
			assertTrue(element.getLastName().equals("Smith"));
			assertTrue(element.getPhone().equals("0987654321"));
			assertTrue(element.getAdress().equals("my short adress"));
			
		}
		
	}
   // @Disabled
    @Test
   	void testContactServiceUpdateContact() 
   	{ //"8675309505", "Jacob", "Jameson", "8771500123", "my different adress"
   		ArrayList<Contact> tempArrayList = new ArrayList<Contact>(0);
   		ContactService testList = new ContactService(); 
   		testList.addContact("1234567890", "John", "Smith", "0987654321", "my short adress");
   		testList.updateFirstName("1234567890", "Jacob");
   		testList.updateLastName("1234567890", "Jameson");
   		testList.updatePhone("1234567890", "8771500123");
   		testList.updateAdress("1234567890","my different adress");
   		tempArrayList = testList.getContactList();
   		
   		Iterator<Contact> listIterator = tempArrayList.iterator();
   		while (listIterator.hasNext())
   		{
   			Contact element = listIterator.next();
   			assertTrue(element.getContactID().equals("1234567890"));
   			assertTrue(element.getFirstName().equals("Jacob"));
   			assertTrue(element.getLastName().equals("Jameson"));
   			assertTrue(element.getPhone().equals("8771500123"));
   			assertTrue(element.getAdress().equals("my different adress"));
   			
   		}
   		testList.deleteContact("1234567890");
		
   		
   	}
    @Test
   	void testContactServiceMultipleContacts() 
   	{ 
   		ArrayList<Contact> tempArrayList = new ArrayList<Contact>(0);
   		ContactService testList = new ContactService(); 
   		testList.addContact("1234567890", "John", "Smith", "0987654321", "my short adress");
   		testList.addContact("8675309505", "Jacob", "Jameson", "8771500123", "my different adress");
   		tempArrayList = testList.getContactList();
   		
   		Iterator<Contact> listIterator = tempArrayList.iterator();
   		int count = 0;
   		while (listIterator.hasNext())
   		{
   			Contact element = listIterator.next();
   			
   			if (count == 0)
   			{
   			assertTrue(element.getContactID().equals("1234567890"));
			assertTrue(element.getFirstName().equals("John"));
			assertTrue(element.getLastName().equals("Smith"));
			assertTrue(element.getPhone().equals("0987654321"));
			assertTrue(element.getAdress().equals("my short adress"));
   			}
   			if (count == 1)
   			{
   				assertTrue(element.getContactID().equals("8675309505"));
   				assertTrue(element.getFirstName().equals("Jacob"));
   				assertTrue(element.getLastName().equals("Jameson"));
   				assertTrue(element.getPhone().equals("8771500123"));
   				assertTrue(element.getAdress().equals("my different adress"));
   			}
   			count++;
   		}
   	}
    @Test
   	void testContactServiceDuplicateContacts() 
   	{ 
   		ContactService testList = new ContactService(); 
   		testList.addContact("1234567890", "John", "Smith", "0987654321", "my short adress");
   		Assertions.assertThrows(IllegalArgumentException.class, () ->
		{
			testList.addContact("1234567890", "John", "Smith", "0987654321", "my short adress");
	
		});	
   	
   		
    }
}
