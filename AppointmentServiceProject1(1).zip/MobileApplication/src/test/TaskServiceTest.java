package test;

import static org.junit.Assert.assertTrue;

import task.TaskService;
import task.Task;
import java.util.*;
import java.util.ArrayList;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
/*TEST TEMPLATES
TaskService("12345678901", "do homework longer than 20", "make sure that one of the test cases has a description over 50"); //all invalid
TaskService("1234567890", "do homework", "finish test cases"); // all valid
TaskService("8675309505", "complete project", "openGL 3d modeling"); //all valid
*/
//@TestInstance(Lifecycle.PER_CLASS)
class TaskServiceTest {
	//@Disabled
	@Test
	
	void testContactServiceIDTooLong() 
	{
		Assertions.assertThrows(IllegalArgumentException.class, () ->
		{
			new TaskService("12345678901", "do homework", "finish test cases");
	
		});
		
		
	}
	//@Disabled
	@Test
	void testTaskServiceTaskNameTooLong() 
	{
		Assertions.assertThrows(IllegalArgumentException.class, () ->
		{
			new TaskService("1234567890",  "do homework longer than 20", "finish test cases");
	
		});
		
		
	}
	@Test
	void testTaskServiceDescriptionTooLong() 
	{
		Assertions.assertThrows(IllegalArgumentException.class, () ->
		{
			new TaskService("1234567890", "do homework", "make sure that one of the test cases has a description over 50");
	
		});
		
		
	}
	//@Disabled
	@Test
	void testTaskServiceIDNULL() 
	{
		Assertions.assertThrows(IllegalArgumentException.class, () ->
		{
			new TaskService(null, "do homework", "finish test cases");
	
		});
		
		
	}
	//@Disabled
	@Test
	void testTaskServiceTaskNameNULL() 
	{
		Assertions.assertThrows(IllegalArgumentException.class, () ->
		{
			new TaskService("12345678901", null, "finish test cases");
	
		});
		
		
	}
	//@Disabled
	@Test
	void testTaskServiceDescriptionNull() 
	{
		Assertions.assertThrows(IllegalArgumentException.class, () ->
		{
			new TaskService("1234567890", "do homework",  null);
	
		});
		
		
	}
	//@Disabled
    @Test
	void testTaskServiceAddTask() 
	{ 
		ArrayList<Task> tempArrayList = new ArrayList<Task>(0);
    	     
		TaskService testList = new TaskService(); 
		testList.addTask("1234567890", "do homework", "finish test cases");
		tempArrayList = testList.getTaskList();//this is necessary because i made the list private
		Iterator<Task> listIterator = tempArrayList.iterator();
		while (listIterator.hasNext())
		{
			Task element = listIterator.next();
			assertTrue(element.getTaskID().equals("1234567890"));
			assertTrue(element.getTaskName().equals("do homework"));
			assertTrue(element.getTaskDescription().equals( "finish test cases"));
			
		}
		
	}
   // @Disabled
    @Test
   	void testTaskServiceUpdateTask() 
   	{ //"8675309505", "complete project", "openGL 3d modeling"
   		ArrayList<Task> tempArrayList = new ArrayList<Task>(0);
   		TaskService testList = new TaskService(); 
   		testList.addTask("1234567890", "do homework", "finish test cases");
   		testList.updateTaskName("1234567890", "complete project");
   		testList.updateDescription("1234567890","openGL 3d modeling");
   		tempArrayList = testList.getTaskList();
   		
   		Iterator<Task> listIterator = tempArrayList.iterator();
   		while (listIterator.hasNext())
   		{
   			Task element = listIterator.next();
   			assertTrue(element.getTaskID().equals("1234567890"));
			assertTrue(element.getTaskName().equals("complete project"));
			assertTrue(element.getTaskDescription().equals("openGL 3d modeling"));
   			
   		}
   		testList.deleteTask("1234567890");
   		
   		Assertions.assertThrows(NoSuchElementException.class, () ->
		{
			testList.notEmptyValidation();
	
		});
   		
   	}
    @Test
   	void testTaskServiceMultipleTasks() 
   	{ //"1234567890", "complete project", "openGL 3d modeling"
    	//"8675309505", "check work", make sure all test cases accounted for"
   		ArrayList<Task> tempArrayList = new ArrayList<Task>(0);
   		TaskService testList = new TaskService(); 
   		testList.addTask("1234567890", "do homework", "finish test cases");
   		testList.addTask("8675309505", "check work", "make sure all test cases accounted for");
   		tempArrayList = testList.getTaskList();
   		
   		Iterator<Task> listIterator = tempArrayList.iterator();
   		int count = 0;
   		while (listIterator.hasNext())
   		{
   			Task element = listIterator.next();
   			
   			if (count == 0)
   			{
   			assertTrue(element.getTaskID().equals("1234567890"));
			assertTrue(element.getTaskName().equals("do homework"));
			assertTrue(element.getTaskDescription().equals("finish test cases"));
   			}
   			if (count == 1)
   			{
   				assertTrue(element.getTaskID().equals("8675309505"));
   				assertTrue(element.getTaskName().equals("check work"));
   				assertTrue(element.getTaskDescription().equals("make sure all test cases accounted for"));
   			}
   			count++;
   		}
   	}
    @Test
   	void testTaskServiceDuplicateTasks() 
   	{ //"1234567890", "complete project", "openGL 3d modeling"
    	//"8675309505", "check work", make sure all test cases accounted for"
   		TaskService testList = new TaskService(); 
   		testList.addTask("1234567890", "do homework", "finish test cases");
   		Assertions.assertThrows(IllegalArgumentException.class, () ->
		{
			testList.addTask("1234567890", "check work", "make sure all test cases accounted for");
	
		});	
   	}
}

